import logo from './logo.svg';
import './App.css';
import React, { useState } from 'react';
// import Card from './components/Card';

// class App extends React.Component {
//   constructor() {
//     super();
//     this.state = {
//       name: 'Halo2'
//     }
//   }
//   render() {
//     return (
//       <p className="judul">Halo, ini pake class Component</p>
//     )
//   }
// }

function App() {

  console.log('tes');
  const [click, setClick] = useState(100);
  const [nama, setNama] = useState('Bambang');

  // function klikGan() {
  //   alert('tes yuk');
  // }

  const klikGan = () => {
    alert('tes yuk yuk yuk');
  }

  return (
    <div className="App">
      <div className="judul">Tes 123</div>
      <button onClick={klikGan}>Yuk Klik</button>

      <div>Counter App</div>
      <p>Anda ngeklik {click} kali</p>
      <button onClick={() => setClick(click + 2)}>Klik +</button>
      <button onClick={() => setClick(click - 2)}>Klik -</button>


      <div>------------------</div>
      {/* <Card nama={nama} /> */}
      <p>Ini Kartu</p>
      <p>{nama}</p>
      <button onClick={() => setNama('mas Rahadian')}>Ubah nama!</button>
    </div>
  );
}

export default App;
